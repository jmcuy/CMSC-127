-- Delete a tweet given its id.
--
-- You have access to the following variables which can be used as placeholders
-- for actual values:
--     - id
--
-- Write your query below:
DELETE FROM tweets WHERE id = '{{id}}';